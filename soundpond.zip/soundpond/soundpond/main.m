//
//  main.m
//  soundpond
//
//  Created by Julie Lee on 4/5/14.
//  Copyright (c) 2014 Julie Lee. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
