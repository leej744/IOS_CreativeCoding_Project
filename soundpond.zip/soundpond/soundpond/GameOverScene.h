//
//  GameOverScene.h
//  soundpond
//
//  Created by Julie Lee on 4/5/14.
//  Copyright (c) 2014 Julie Lee. All rights reserved.
//

#import "MyScene.h"

@interface GameOverScene : MyScene

@end
