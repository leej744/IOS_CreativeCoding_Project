//
//  WinScene.h
//  soundpond
//
//  Created by Julie Lee on 4/8/14.
//  Copyright (c) 2014 Julie Lee. All rights reserved.
//

#import "MyScene.h"

@interface WinScene : MyScene

@end
